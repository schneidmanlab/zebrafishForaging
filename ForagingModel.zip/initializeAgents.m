function [Sim_step,Sim_turn,Theta,move_type,x,y] = ...
    initializeAgents(N,x_st,y_st,theta0,flake_pos,flake_th,boundery)
%description: intilaize agents in the arena, and behavior variables.
%Supprots cases where initilaze positions are given or not. 


%Input: x_st,y_st - inital positions of agents vectors of length N or empty
%       theta0 - direction of motion, vector of length N 
%       flake_pos -  flake positions in the arena 
%       flake_th - range of flakes detction - integer
%       boundery - Lx2 defining arena boundery



%Output: Sim_Step, Sim_turn - cell array of simulated steps and turns
%        Theta - cell aray of fish angle orientaiton in space
%        move_type - cell array to record move types [toward flake, toward
%        neighbor, random, etc']
%        x,y - cell array of the simulated positions



%...........Local Variable definitions..........


%.................Main Function.................

%take coordinates of flakes
x_flake = flake_pos(:,1); y_flake = flake_pos(:,2);

%variables for all fish
Sim_turn = cell(1,N); Sim_step = Sim_turn; x = Sim_turn; y = x;
Theta = cell(1,N); move_type = cell(1,N);


for a = 1:N % for all agents
    %create data variables
    x{a} = zeros(1,30000); y{a} = x{a}; % initialze as very long
    Sim_step{a} = x{a}; Sim_turn{a} = x{a}; Theta{a} = x{a};
    move_type{a} = x{a};
    
    i = 1; % first positon
    
    %take maximum values of boundery data (assumes min is 0)
    bx_max = max(boundery(:,1));
    by_max = max(boundery(:,2));
    
    if ~isempty(x_st) %if starting positions are given use them
        x{a}(i) = x_st(a);
        y{a}(i) = y_st(a);
        Theta{a}(i) = theta0(a);
    else %draw them randomly
        
        
        flag = 0;
        %determin random starting position:
        while ~flag
            x{a}(i) = rand(1)*bx_max;
            y{a}(i) = rand(1)*by_max;
            Theta{a}(i) = theta0(a);
            
            % check that all positions are within the arena
            flag = inpolygon(x{a}(i),y{a}(i),boundery(:,1),boundery(:,2));
            
            if flag
                %check that distance from flakes is lareger then TH
                vec = [x_flake-x{a}(i) y_flake-y{a}(i)];
                D = calculateNorm(vec);
                %if there flake in the region try again
                flag2 = sum(D<flake_th(a));
                if flag2
                    flag = 0;
                end
            end
        end
    end
end


%............Call for local functions...........




