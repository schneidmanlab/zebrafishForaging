function [x_new, y_new, curr_step, curr_turn, curr_theta,move_type] = ...
    goToNeighborConsumption(agent_pos, agent_prev_theta,prev_flake_pos, Steps, boundery, varargin)
%description: draws a legal move (ending inside the bounderies of the arena
%towards the closest neighbor detecting flakes


%Input: agent_pos - current agent position [1x2]
%       agent_prev_theta - previous swimming angle in space (deg)
%       prev_flake_pos - previous position of flake consumed by neighbor
%       Steps - vector of step size distribution (in body lengths)
%       boundery - arena bounderies [L x 2]




%Output: x_new, y_new - new agent position
%        curr_step - size of the current step
%        curr_theta - new angle in space
%        move_type - 2 - go to neighbor consumptions



%...........Local Variable definitions..........
% set defaults
default_countTH = 500; 

 
% parse
vars = inputParser;
addParameter(vars,'countTH',default_countTH);

 
 
parse(vars,varargin{:})
% make variables
COUNT_TH = vars.Results.countTH; % threshold for drawing a legal move

% agent previous pos
x_prev = agent_pos(1);
y_prev = agent_pos(2);


% bounderies
int_boundery_x = boundery(:,1);
int_boundery_y = boundery(:,2);


%.................Main Function.................
flag = 0; % 0 if legal move was not drawn, 1 if it did
COUNT = 0; % counter for number of attempts
while ~flag
    
    % if count_th moves were drawn unsuccessfully for count_th times  - 
    % make step smaller that distance to closes wall
    if COUNT > COUNT_TH % the distance to flake is too small
        % choose move the be the shortest path to wall to keep agent inside
        DD = calculateNorm([int_boundery_x - x_prev int_boundery_y-y_prev]);
        curr_step = min(DD)*0.95;
    else
        
        curr_step = emprand(Steps); %draw a step length (maybe larger than up to detection point);
    end
    
    % direction to detection point
    curr_dir = [prev_flake_pos(1) - x_prev prev_flake_pos(2) - y_prev];
    
    % take a step in the direction of the flake at the length
    % decided
    curr_move = curr_dir/calculateNorm(curr_dir).*curr_step;
    
    %currnet turn and current angle
    [~, curr_turn] = angOfVectors([cosd(agent_prev_theta) sind(agent_prev_theta)],curr_move,1);
    curr_turn(curr_turn>180) = curr_turn(curr_turn>180) - 360;
    [~, curr_theta] = angOfVectors([1 0],curr_move,1);
    
    %move in the direction of the flake
    x_new = x_prev + curr_move(1); y_new = y_prev + curr_move(2);
    flag = inpolygon(x_new,y_new,boundery(:,1),boundery(:,2));
    COUNT = COUNT +1;
    move_type = 2;
end


%............Call for local functions...........




