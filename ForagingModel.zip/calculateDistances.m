function [minDflake,minIflake,minDNflake,minINflake,Dneigh,...
    x_flake_prev,y_flake_prev] = calculateDistances...
    (x,y,i,a,det_times,x_flake,y_flake,varargin)
%description: calculate distances from current fish to flakes, neighbor
%flake detections and neighbors


%Input: x,y - agent simulated positions
%       i - integer - current time
%       a - current fish
%       det_times - data of detected flakes [cols: position, id ofdetecting
%       fish, flake_x, flake_y]
%       x_flake, y_flake - positions of currently available flakes




%Output: minDflake - distance to closes flake
%        minIflake - id of closest distance
%        minDNflake - distance to closest neighbor that detected a flake in
%        the last tau time steps
%        minINflake - id of closest neighbor the detected a flake in the
%        last tau time steps
%        Dneigh - distance to neighbors
%        x_flake_prev, y_flake_prev - positions of previously detected
%        flakes



%...........Local Variable definitions..........
% set defaults
default_tau = 4; % time steps to remember neighbor's flake detections 

% parse
vars = inputParser;
addParameter(vars,'tau',default_tau);

parse(vars,varargin{:})
% make variables
tau = vars.Results.tau;


% previous agent position
x_prev = x{a}(i-1);
y_prev = y{a}(i-1);



%.................Main Function.................

%calc distance to flakes
vec = [x_flake-x_prev y_flake-y_prev];
D = calculateNorm(vec);
[minDflake, minIflake] = min(D);

% get distance to neighbors:
x_prev_neigh = cellfun(@(x) x(i-1),x)';
y_prev_neigh = cellfun(@(x) x(i-1),y)';

% calculate distance to neighbors:
Dneigh = calculateNorm([x_prev - x_prev_neigh, y_prev - y_prev_neigh]);

Dneigh(a) = 2000; % make sure self is not included 

%get data of previously detected flakes
x_flake_prev = det_times(:,3); y_flake_prev = det_times(:,4);
flake_prev_time = det_times(:,1); flake_prev_id = det_times(:,2);

%lose own detections
x_flake_prev(flake_prev_id==a) = []; y_flake_prev(flake_prev_id==a) = [];
flake_prev_time(flake_prev_id==a) = [];

%lose old detections (5 steps ago):
x_flake_prev(flake_prev_time+tau<i) = []; y_flake_prev(flake_prev_time+tau<i) = [];

%lose no detections
x_flake_prev(x_flake_prev==0) = [];   y_flake_prev(y_flake_prev==0) = [];


%calc distance to neighbors detecting flakes
vecN = [x_flake_prev-x_prev y_flake_prev-y_prev];
DN = calculateNorm(vecN);
[minDNflake,minINflake] = min(DN);

if isempty(minDNflake)
    minDNflake = 2000; % replace empty with an arbitrarily large value
end


%............Call for local functions...........




