function [x_new,y_new,curr_step,curr_turn, curr_theta, move_type] = drawRandomMove...
    (agent_pos, agent_theta,Steps,Turns, boundery)
%description: draw a random step size and turning angle and calculates the
%next move and position of fish


%Input: agent_pos - x,y of agent (1x2)
%       agent_theta - absolute angle in space
%       Steps - vector of the distribution of step sizes
%       Turns - vector of the distribution of turn angles
%       boundery - arena boundery (Nx2)


%Output: x_new,y_new - new agents position after legal move
%        curr_step - size of the step that was chosen
%        curr_turn - turn from previous direciton
%        curr_theta - new absolute angle in space
%        move_type - 3 - draw random move



%...........Local Variable definitions..........

x_prev = agent_pos(1);
y_prev = agent_pos(2);

%.................Main Function.................
%keep drawing steps and turns making sure next step is inside the
%boundery
flag = 0;
while ~flag
    
    %draw turns and steps
    curr_step = emprand(Steps);
    curr_turn = emprand(Turns);
    
    %calculate new direction of motion
    curr_theta = agent_theta+curr_turn;
    
    %calculate next position
    x_new = x_prev+curr_step*cosd(curr_theta);
    y_new = y_prev+curr_step*sind(curr_theta);
    
    %check if it is inside the boundery
    flag = inpolygon(x_new,y_new,boundery(:,1),boundery(:,2));
    move_type = 3;
end


%............Call for local functions...........




