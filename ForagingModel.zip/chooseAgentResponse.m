function [go_for_flake, go_for_neigh_detection, go_for_neigh] = ...
    chooseAgentResponse(flake_th,neigh_th,d_flake,d_neigh_feed,...
    d_neigh, model_type)
%description: decide the action an agent will take
%'go_to_flake','go_to_neighbor_detection','respond_to_neighbor', or none 
% (draw a random step and turn), according to the specific model type used. 


%Input: flake_th,neigh_th - integers indicating the neighbor and flake
%                           detection ranges
%       d_flake - distance to the closest flake
%       d_neigh_feed - distance to the closest detection point by a
%                      neighbor
%       d_neigh - a vector if Nx1 with distances to all neighbors in the
%                 last time step
%       model_type - string indicating model type e.g. 'Att',
%                    'Att_feed','IND', 'etc'



%Output: response flags of 0 or 1
%        go_for_flake, go_for_neigh_detection, go_for_neigh



%...........Local Variable definitions..........

% choose which responses are used according to the 7 model types: 
switch model_type
    case 'IND'
        response_to_neigh_detction = false;
        response_to_neigh = false;
    case 'Att_feed'
        response_to_neigh_detction = true;
        response_to_neigh = false;
    case {'Att','Align','Att+Align'}
        response_to_neigh_detction = false;
        response_to_neigh = true;
    case {'Att_feed+Align','Att_feed+Att+Align'}
        response_to_neigh_detction = true;
        response_to_neigh = true;        
end

% neighbors within range:
neigh_in_range = d_neigh < neigh_th;


%.................Main Function.................


%check if a flake is at a noticable distance if so, stochastically
%decide if to move towards it:
if d_flake < flake_th
    Prob = 1/exp(d_flake/flake_th); %probability to move to flake
    go_for_flake = rand(1)<Prob; %decide if to go for flake or not.
    go_for_neigh_detection = 0;
    go_for_neigh = 0;
    %check if flake was found in a previous tau steps by a near neighbor
elseif (d_neigh_feed < neigh_th) && response_to_neigh_detction
    Prob = 1/exp(d_neigh_feed/neigh_th); %probability to move to neighbor flake detectoin
    go_for_neigh_detection = rand(1)<Prob;
    go_for_flake = 0;
    go_for_neigh = 0;
    %check if neighbors were within range in the previous step
elseif sum(neigh_in_range)>0 && response_to_neigh
    mean_neigh_d = mean(d_neigh(neigh_in_range));
    Prob = 1/exp(mean_neigh_d/neigh_th); %probability to move to closest neighbor
    go_for_neigh = rand(1)<Prob;
    go_for_neigh_detection = 0;
    go_for_flake = 0;
    % no neighbor or flake responses are used:
else
    go_for_neigh = 0;
    go_for_flake = 0;
    go_for_neigh_detection = 0;
end
            
            
            
            
%............Call for local functions...........




