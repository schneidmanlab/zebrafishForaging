function plotSimVsRealData(x,y,sim_det_times,x_real,y_real,real_det_times,varargin)
% plots the consumption dynamics, avg nearest neighbor distance and avg
% polarity in simulaiton repetitions compared to real data:


%
%...........Local Variable definitions..........
% set defaults
default_avg_BL = 30;
default_Fs = 50;
default_model_name = 'model';
% parse
vars = inputParser;
addParameter(vars,'avg_BL',default_avg_BL);
addParameter(vars,'Fs',default_Fs);
addParameter(vars,'model_name',default_model_name);



parse(vars,varargin{:})
% make variables
avg_BL = vars.Results.avg_BL;
Fs = vars.Results.Fs;
model_name = vars.Results.model_name;

%% .................Main Function.................


% motion vectors:
vecx = x_real(:,2:end) - x_real(:,1:end-1);
vecy = y_real(:,2:end) - y_real(:,1:end-1);

% vector length 
S = calculateNorm(cat(3,vecx,vecy));
% direction vectors
dirx = vecx./S;
diry = vecy./S;

% calculate polarity in data
pol_data = [calculateNorm([mean(dirx)' mean(diry)']); 0];

% calculate polarity, NN1 
avgpol_data = nanmean(pol_data);
stdpol_data = nanstd(pol_data);

% calculate distance between fish
NN1_data = nnDistance(x_real,y_real);

avgnn1_data = nanmean(NN1_data(:));
stdnn1_data = nanstd(NN1_data(:));


% calculate these properties in the simulations
n_reps = length(x); % all simulation repetitions
all_sim_pol = zeros(1, n_reps);
all_sim_nn1 = zeros(1, n_reps);
for i_rep = 1: n_reps
    
    % psoitions
    x_f = cell2mat(x{i_rep}');
    y_f = cell2mat(y{i_rep}');
        
    
    % length of data
    L = size(x_f,2);
    
    % velocity
    vx = x_f(:,2:end) - x_f(:,1:end-1);
    vy = y_f(:,2:end) - y_f(:,1:end-1);
    % vector length
    S = calculateNorm(cat(3,vx,vy));
    % dir
    dirx = vx./S;
    diry = vy./S;
    
    % calculate polarity
    pol = [calculateNorm([mean(dirx)' mean(diry)']); 0];
    all_sim_pol(i_rep) = mean(pol);
    % calculate NN distance
    sim_nn1 = nnDistance(x_f,y_f);
    all_sim_nn1(i_rep) = mean(sim_nn1(:));
        
end



% plot results
Cmap = lines;
figure();
subplot(1,4,1);
% plot mean pol
errorbar(mean(all_sim_pol),std(all_sim_pol),'color',Cmap(1,:),'LineWidth',2);hold on;
plot(mean(all_sim_pol),'.','color',Cmap(1,:),'MarkerSize',20);
plot(avgpol_data,'k.','MarkerSize',20);  
box off;
xlim([0.5 1.5]);
ylabel('Polarity'); 
set(gca,'Xtick',1,'XtickLabel',model_name);
ylim([mean(all_sim_pol) - 2*std(all_sim_pol) mean(all_sim_pol) + 2*std(all_sim_pol)]);

subplot(1,4,2);
% plot mean nn1
errorbar(mean(all_sim_nn1),std(all_sim_nn1),'color',Cmap(1,:),'LineWidth',2);hold on;
plot(mean(all_sim_nn1),'.','color',Cmap(1,:),'MarkerSize',20); 
plot(avgnn1_data,'k.','MarkerSize',20);  
box off;
xlim([0.5 1.5]);
ylabel('D_{nn1}'); 
set(gca,'Xtick',1,'XtickLabel',model_name);
ylim([mean(all_sim_nn1) - 2*std(all_sim_nn1) mean(all_sim_nn1) + 2*std(all_sim_nn1)]);

subplot(1,4,3:4);
% plot the detections times
l1 = boundedLine((1:length(real_det_times))',mean(sim_det_times,2),...
    std(sim_det_times,[],2),'cmap',Cmap(1,:));
hold on;
l2 = plot(real_det_times,'k.-','LineWidth',2,'MarkerSize',15);
box off;
legend([l1,l2],{'Sim','Data'}); legend boxoff;
xlabel('Flake #'); ylabel('Time to consumption [s]'); 





