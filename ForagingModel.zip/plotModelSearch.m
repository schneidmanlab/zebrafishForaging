function plotModelSearch(x,y,i,x_flake,y_flake,boundery,varargin)
%description: 


%Input: x,y of agents [cell arrays of length N]
%       i - current search time
%       x_flake,y_flake - x,y of flake
%       boundery - arena boundery (Nx2)


%Output: 



%...........Local Variable definitions..........
% set defaults
default_Pause = 0.01; 

% parse
vars = inputParser;
addParameter(vars,'Pause',default_Pause);

parse(vars,varargin{:})
% make variables
Pause = vars.Results.Pause;



N = length(x);

%.................Main Function.................
Cmap = lines;
figure(1)
for a = 1:N
    ii = i-4:i; ii(ii<1) = [];
    plot(x{a}(ii),y{a}(ii),'.-','color',Cmap(a,:));
    hold on;
    plot(boundery(:,1),boundery(:,2),'k');
    plot(x_flake,y_flake,'k.');
    title(['Time: ',num2str(i)])
end
if isempty(Pause)
    pause();
else
    pause(Pause);
end
hold off;


%............Call for local functions...........




