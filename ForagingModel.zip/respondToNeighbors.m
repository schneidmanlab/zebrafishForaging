function [x_new,y_new,curr_turn,curr_step,curr_theta,move_flag] = ...
    respondToNeighbors(curr_t,curr_f,Steps,Turns,Theta,x,y,...
    d_neigh, neigh_th, all_bounderies, model_type,varargin)
%description: caclulate fish movement direction in response to its neighbors
%according to the social interactions unrelated to flakes, in the 'Att','Align'
%or 'Att_feed+Align','Att+Align', 'Att_feed+Att+Align' models


%Input: curr_t - current time point in experiment
%       curr_f - id of current fish
%       Steps, Turns - distribution of turns and steps of current fish
%       Theta - cell array of 1xN of angle of motion of each fish over exp
%       x, y - cell array of 1xN of position each fish over exp
%       d_neigh - vector N x 1 distance to all neighbors
%       neigh_th - integer, range of neighbor detection
%       boundery - matrix with columns representing x,y positions of boundery
%       model_type - string - 'Att', 'Align' or 'Att+Align'

%       optional:
%       countTH - threshold for number of attempts to draw a legal move
%       (default - 500)
%       wallTH - if fish are closer then wallTH (in body lengths) don't
%       respond to neighbors 


%Output: % x_new,y_new - new agent positions
%        curr_turn - angle of turn of chosen move
%        curr_step - step size of chosen move
%        curr_theta - new angle in space of agent
%        move_flag - 5 if response to neighbor, 4 if cancelled and draw
%                    random step



%...........Local Variable definitions..........
% set defaults
default_countTH = 500; % threshold 
default_wallTH = 0.4;


% parse
vars = inputParser;
addParameter(vars,'countTH',default_countTH);
addParameter(vars,'wallTH',default_wallTH);


parse(vars,varargin{:})
% make variables
COUNT_TH = vars.Results.countTH; % number of attempts to draw a legal move
WALL_TH = vars.Results.wallTH; % threshold to avoid walls


% %.................Main Function.................


stop_flag = 0;

COUNT = 1; % count the number of attempts

% take current fish previous positions
x_prev = x{curr_f}(curr_t-1);
y_prev = y{curr_f}(curr_t-1);

% take previous positions of all fish
x_prev_neigh = cellfun(@(x) x(curr_t-1),x)';
y_prev_neigh = cellfun(@(x) x(curr_t-1),y)';

% previous direction 
theta_prev = Theta{curr_f}(curr_t-1);

% for efficiency use interpulated and non interpulated bounderies
% seperately:
boundery = all_bounderies{1};
int_boundery_x = all_bounderies{2}(:,1);
int_boundery_y = all_bounderies{2}(:,2);

while ~stop_flag % as long as a legal move was not drawn
    
    % find minimal distance to wall from fish previous positions
    DD = min(calculateNorm([int_boundery_x - x_prev int_boundery_y-y_prev]));
    
    % count the number of attempts to respond to neighbor, and check if the
    % fish is not too close to the wall
    if COUNT <= COUNT_TH && DD >= WALL_TH
        
        curr_step = emprand(Steps); %draw a step length
        
        
        switch model_type % choose response according to model
            
            case 'Att'
                % find neighbors in range
                neigh_in_range_att =  d_neigh < neigh_th;
                
                
                % take position of neighbors to attract to
                curr_neigh = [x_prev_neigh(neigh_in_range_att) ...
                    y_prev_neigh(neigh_in_range_att)];
                % move the center of mass of neighbors
                curr_move = [mean(curr_neigh(:,1)) - x_prev ...
                    mean(curr_neigh(:,2)) - y_prev];
                curr_move = curr_move./norm(curr_move); % normalize
                
            case {'Align','Att_feed+Align'}
                % find neighbors in range
                neigh_in_range_align = d_neigh < neigh_th;
                
                % take direction of motion of neighbors
                curr_neigh_theta = cellfun(@(x) x(curr_t-1),Theta)';
                curr_neigh_theta = curr_neigh_theta(neigh_in_range_align);
                
                % calculate move towards the average of the direction
                % vector of the neighbros:
                
                % find mean vector of neighbors and self
                mean_neigh_vec = mean([cosd(curr_neigh_theta) sind(curr_neigh_theta)],1);
                
                % new direction is mean angle of neighbors - calcualte new
                % direction in space
                
                % direction of motion is mean of neighbors
                curr_move = mean_neigh_vec;
                
                curr_move = curr_move/calculateNorm(curr_move);% normalize
                
            case  {'Att+Align','Att_feed+Att+Align'}
                % seperate neigh_th to att and align zones
                neigh_in_range_att =  d_neigh >= neigh_th/2 & d_neigh < neigh_th;
                neigh_in_range_align = d_neigh < neigh_th/2;
                
                % caluclate attraction response 
                curr_neigh = [x_prev_neigh(neigh_in_range_att) ...
                    y_prev_neigh(neigh_in_range_att)];
                % attraction to center of mass
                curr_move_att = [mean(curr_neigh(:,1)) - x_prev ...
                    mean(curr_neigh(:,2)) - y_prev];
                curr_move_att = curr_move_att./norm(curr_move_att); % normalize
                
                % calculate alignment response to average
                % neighbor direction
                curr_neigh_theta = cellfun(@(x) x(curr_t-1),Theta)';
                curr_neigh_theta = curr_neigh_theta(neigh_in_range_align);
                
                % average neighbor direction
                mean_neigh_vec = mean([cosd(curr_neigh_theta)...
                    sind(curr_neigh_theta)],1);
                
                % new direction of motion is mean of neighbors
                curr_move_align = mean_neigh_vec;
                curr_move_align = curr_move_align./norm(curr_move_align); % normalize
                
                % average and att and align responses:
                curr_move = (curr_move_att + curr_move_align)./2;
                curr_move = curr_move/calculateNorm(curr_move); % normalize
                
        end
        
        % multiply by step size:
        curr_move = curr_move * curr_step;
        
        %calculate currnet turn and current new angle
        [~, curr_turn] = angOfVectors([cosd(theta_prev) sind(theta_prev)],curr_move,1);
        curr_turn(curr_turn>180) = curr_turn(curr_turn>180) - 360;
        [~, curr_theta] = angOfVectors([1 0],curr_move,1);
        
        %move in the direction of the flake
        x_new = x_prev + curr_move(1); y_new = y_prev + curr_move(2);
        move_flag = 5; % response to neighbors regardless of flakes
        
    else
        
        %draw turns and steps
%         rng(COUNT);
        curr_step = emprand(Steps);
        curr_turn = emprand(Turns);
        
        %calculate new direction of motion
        curr_theta = theta_prev+curr_turn;
        
        %calculate next position
        x_new = x_prev+curr_step*cosd(curr_theta);
        y_new = y_prev+curr_step*sind(curr_theta);
        %                             disp(['neighbor attraction canceled wall D: ',num2str(DD),...
        %                                 ' count: ',num2str(COUNT)]);
        move_flag = 4; % no neighbor response
        
        
    end
    COUNT = COUNT +1; % increase attempt counter
    
    % check if this is a legal move (inside bounderies)
    stop_flag = inpolygon(x_new,y_new,boundery(:,1),boundery(:,2));
end





