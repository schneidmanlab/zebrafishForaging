function [x_flake, y_flake, updateX, updateY] = ....
    updateFlakes(x_flake, y_flake, minI,updateX, updateY, update_flag)
%description: updates flakes in case new flakes appear after current flakes
%was eaten


%Input: x_flake, y_flake - positions of current flakes
%       minI - id of current flake
%       updateX, updateY - 'reserve flakes' for updating (from experiments)
%       update flag - flag if to do updating or not


%Output: 
%       x_flake, y_flake - positions after update
%       updateX, updateY - 'reserve flakes' after updating



%...........Local Variable definitions..........

%.................Main Function.................

%remove detected flake (Set to nan)
x_flake(minI) = nan; y_flake(minI) = nan;

if update_flag %if we update flake reapearance
    upind = find(updateX(minI,:)~=0,1,'first'); % find first 'reseve flake'
    if ~isempty(upind)
        x_flake(minI) = updateX(minI,upind); % update
        y_flake(minI) = updateY(minI,upind); % update
        % after update remove current 'reserve' flake (set to 0)
        updateX(minI,upind) = 0; 
        updateY(minI,upind) = 0;
    end
end

%............Call for local functions...........




