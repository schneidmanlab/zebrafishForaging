function [NN1] = nnDistance(x,y)
%description: calculates the nearest neighbor distance of each fish to its
%neghbors over time


%Input: x,y, matrices of positions [n fish x time]



%Output: NN1 matrix of distance to nearest neighbor for all fish and all
%        times



%...........Local Variable definitions..........
[N, Ldata] = size(x);


%.................Main Function.................
%save distance from every fish to its neighbors
NN1 = zeros(N,Ldata);



for i = 1:N
    tempX = x; tempY = y;
    %take fish i values
    currX = tempX(i,:); currY = tempY(i,:);
    tempX(i,:) = []; tempY(i,:) = []; %lose from all data set
    %subtruct fish i coor from all
    diffX = tempX-repmat(currX,size(tempX,1),1);
    diffY = tempY-repmat(currY,size(tempY,1),1);
    %save all corresponding distances from fish i
    Distance = calculateNorm(cat(3,diffX,diffY)); 
    % save the nearest neighbor distance
    NN1(i,:) = min(Distance); 
end


%............Call for local functions...........




