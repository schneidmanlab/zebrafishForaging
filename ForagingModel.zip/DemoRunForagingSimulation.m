% demo for using social behavior simulations:

% set data location
data_location = '~/.../';

% set path to toolbox:
toolbox_path = '~/.../';
addpath(genpath(toolbox_path))

% model names for simulations
model_names = {'IND','Att_feed','Att','Align','Att_feed+Align','Att+Align',...
    'Att_feed+Att+Align'};

% just for text lablel purpuse
model_name_for_plotting = {'IND','Att_{feed}','Att','Align','Att_{feed}+Align',...
    'Att+Align','Att_{feed}+Att+Align'};

% general variables:
avg_BL = 30; %body length in pixels
Fs = 50; %frames/sec

% set parameters for group size, groups id, model type used:
group_size = 6; %[1,3,6];
group_id = 10; % [1..num of groups in data]
model_id = 5; % [1.. length(model_names)]


% load group data:
load([data_location,'fish',num2str(group_size)]);

%take relevant movement data
x_real = data{group_id}.x;
y_real = data{group_id}.y;

% swim statistics
Speed = data{group_id}.Speed;
Steps = data{group_id}.Steps;
Turns = data{group_id}.Turns;

% flake data
flake_pos = data{group_id}.flakes_xy_for_sim;
boundery = [data{group_id}.border_x data{group_id}.border_y];
consumption_times = data{group_id}.consumption_times/Fs;
Nflakes = size(data{group_id}.flake_xy,1); % number of flakes

N = size(x_real,1); % num fish

% normalize to body lengths
flake_pos = flake_pos./avg_BL;
boundery = boundery./avg_BL;
x_real = x_real./avg_BL;
y_real = y_real./avg_BL;



%% set neighbor and flake thresholds

flake_th = 4;
neigh_th = 13;

n_reps = 20; % number of simulation repetitions
% simulate fish behavior:
x = cell(1, n_reps); y = cell(1, n_reps);
Sim_step = cell(1, n_reps); Sim_turn = cell(1, n_reps);
move_type = cell(1, n_reps); det_times = cell(1, n_reps);
all_reps_fish = cell(1, n_reps);
sim_det_times = zeros(Nflakes,n_reps);

for i = 1:n_reps 
    n_resp = N; % number of interacting fish
    
    rng(i) % for reproducability
    
    % simulate current run
    [x{i},y{i},Sim_step{i},Sim_turn{i},move_type{i},det_times{i},all_resp_fish{i}] =...
        simulateForagingFish(Steps,Turns,model_names{model_id},boundery,flake_pos,flake_th,...
        x_real,y_real,neigh_th,n_resp,0);
    
    % transform to real time using the avg speed of the fish:
    avg_speed = nanmean(Speed(Speed~=0))./avg_BL*Fs;
    for j = 1:size(sim_det_times,1)
        sim_det_times(j,i) = ...
            sum(Sim_step{i}{det_times{i}(j,2)}(1:det_times{i}(j,1)))./avg_speed;
    end
    disp(['finished sim # ',num2str(i)])
end

sim_det_times = sort(sim_det_times);

% plot results of simulation compard to data:

plotSimVsRealData(x,y,sim_det_times,x_real,y_real,consumption_times,'model_name',...
    model_name_for_plotting{model_id})



