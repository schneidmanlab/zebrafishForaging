function [x,y,Sim_step,Sim_turn,move_type,det_times,i_resp] = simulateForagingFish...
    (Steps,Turns,model_type,boundery,flake_pos,flake_th,x_st,y_st,neigh_th,...
    n_partial,PLOT)

%This function implements a correlated random walk model in a bounded arena
% in addition, agents also respond to scattered particles (food) in the arena.
% They can also respond to their neighbors foraging and swimming behavior dependent
% on the social models used [7 possible models]

%Input:
%       Steps - a cell array of 1 x N of vectors of step sizes from real data.
%       Truns - a cell array of 1 x N of vectors of turns from real data.

%       model_type - string that specified the type of model:
%       IND, Att_feed, Att, Align, Att_feed + Aling, Att+Aling, Att_feed+Att+Align

%       boundery - Dx2 matix containing polygon vertices of arena bounderies

%       flake_pos  - an Nx2 matrix of x,y positions of flakes in arena (in BLs).
%       if a matrix of NxPx2 is given then Nx1x2 are the intial positions of
%       flakes and the rest are flake positions that replace the intial positions
%       after they are consumed.

%       flake_th - integer, threshold of flake detection to use in stochastic
%       model

%       x_st, y_st - vectors of Nx1 of starting postions of fish (can be ommited).

%       neigh_th - threshold for neighbor detection.


%       n_partial - number of n out of N neighbors responding to social info
%       [needed only if simulating partial number of social neighbors]



%Output:
%       x,y - cell arrays of fish simulated trajectoris;
%       Sim_step,Sim_turn - cell arrays of the simulated step length and turns

%       det_times - N_flakes x 4 matrix with the following data: col1 - times of
%       detection, col2 - id of detecting fish, cols 3:4 - positions of
%       the detected flakes.

%       i_resp = the index of the responding fish in the simulations [meaningful
%       only in the case of simulating a partial number of social neighbors]


%...........Local Variable definitions..........


%check what type of flake data we have:
if length(size(flake_pos))==3 %if we have positions that update during simulation
    update_flag = 1;
    updateX = squeeze(flake_pos(:,2:end,1)); %take update data
    updateY = squeeze(flake_pos(:,2:end,2));
    flake_pos = squeeze(flake_pos(:,1,:)); %take initial flake positions
else
    update_flag=0;
end

% number of agents
N = length(Turns);

% initial fish swim angles theta
theta0 = 180 - rand(1,N)*360;


% make Df values vector with length N
if length(flake_th)==1
    flake_th = ones(1,N)*flake_th;
end

% allow for a fraction of the N neighbor to respond (if N_partial < N)
if length(neigh_th)==1 && n_partial == N % if all fish show social responses
    neigh_th = ones(1,N)*neigh_th;
    i_resp = 1:N;
else
    % choose the responding neighbors
    i_resp = randperm(N);
    i_resp = i_resp(1:n_partial);
    temp_neigh_th = neigh_th;
    neigh_th = zeros(1,N);
    neigh_th(i_resp) = temp_neigh_th; % set their neighbor th to 1
end


% interpulated boundery to use to estimate accurate distance of fish to
% border
int_boundery_x = interp1(1:size(boundery,1),boundery(:,1),1:0.1:size(boundery,1))';
int_boundery_y = interp1(1:size(boundery,1),boundery(:,2),1:0.1:size(boundery,1))';

% a variable with interpulated and original bounderies
all_bounderies{1} = boundery;
all_bounderies{2} = [int_boundery_x int_boundery_y];



%.................Main Function.................



%% initialize variables and agents positions:
%var for model detection times
det_times = zeros(size(flake_pos,1),4);

%take coordinates of flakes
x_flake = flake_pos(:,1); y_flake = flake_pos(:,2);

p = 1; %index for detection time vector

% initilize agent positions
[Sim_step,Sim_turn,Theta,move_type,x,y] = ...
    initializeAgents(N,x_st,y_st,theta0,flake_pos,flake_th,boundery);

i = 2; %advance move counter


%as long as there are flakes and limit not reached
while (sum(isnan(x_flake))<length(x_flake)) && i<=length(x{1})
        
    for a = 1:N % for all fish:
        %take previous position and angle
        x_prev = x{a}(i-1); y_prev = y{a}(i-1); theta_prev = Theta{a}(i-1);
        
        % calculate distances from flakes and neighbors
        [d_flake,d_flakeI,d_neigh_feed,d_neigh_feedI,d_neigh,...
            x_flake_prev,y_flake_prev] = calculateDistances...
            (x,y,i,a,det_times,x_flake,y_flake);
        
        %make a decision to 'go to flake', 'go to neighbor feeding' or
        % 'respond to neighbrs' according to distances and the model
        % used:
        
        [go_for_flake, go_for_neigh_detection, go_for_neigh] = ...
            chooseAgentResponse(flake_th(a),neigh_th(a),d_flake,d_neigh_feed,...
            d_neigh, model_type);
        
        % perfrom moves:
        if go_for_flake % flake response
            
            [x{a}(i), y{a}(i), Sim_step{a}(i), Sim_turn{a}(i), Theta{a}(i),...
                move_type{a}(i)] = goToFlake([x_prev y_prev], theta_prev, ...
                [x_flake(d_flakeI) y_flake(d_flakeI)], Steps{a}, all_bounderies);
            
            %if flake reached - delete it
            if Sim_step{a}(i) >= d_flake
                
                %save postions of flakes eaten
                det_times(p,3:4) = [x_flake(d_flakeI) y_flake(d_flakeI)];
                det_times(p,1) = i; % save detection time
                det_times(p,2) = a; %save the fish detecting
                
                % update flakes (remove current) add new ones if needed
                % (according to real flakes positions and dynamics)
                
                [x_flake, y_flake, updateX, updateY] = ....
                    updateFlakes(x_flake, y_flake, d_flakeI,...
                    updateX, updateY, update_flag);
                
                p = p+1; % update counter for flakes
            end
            
            
        elseif go_for_neigh_detection % previous neighbor feeding response
            
            [x{a}(i), y{a}(i), Sim_step{a}(i), Sim_turn{a}(i), Theta{a}(i),...
                move_type{a}(i)] = goToNeighborConsumption([x_prev y_prev],...
                theta_prev, [x_flake_prev(d_neigh_feedI) y_flake_prev(d_neigh_feedI)],...
                Steps{a}, boundery);
            
        elseif go_for_neigh % response to neighbors
            [x{a}(i),y{a}(i),Sim_turn{a}(i),Sim_step{a}(i),Theta{a}(i),...
                move_type{a}(i)] = respondToNeighbors(i,a,Steps{a},...
                Turns{a},Theta,x,y,d_neigh, neigh_th(a), all_bounderies, model_type);
            
        else
            %randomly draw the next step
            [x{a}(i), y{a}(i),Sim_step{a}(i), Sim_turn{a}(i), Theta{a}(i),...
                move_type{a}(i)] = drawRandomMove([x_prev y_prev],...
                theta_prev,Steps{a},Turns{a}, boundery);
        end
        
        
    end
    
    if PLOT
        plotModelSearch(x,y,i,x_flake,y_flake,boundery,'Pause',0.01)
    end
    
    % advance time counter
    i = i+1;
    
end

% trim variables to the length of the simulation.
for a = 1:N
    x{a}(i:end) = []; y{a}(i:end) = []; Sim_turn{a}(i:end) = []; Sim_step{a}(i:end) = [];
    move_type{a}(i:end) = [];
    move_type{a}(1) = 3;
end

