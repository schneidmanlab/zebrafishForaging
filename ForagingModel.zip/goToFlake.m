function [x_new, y_new, curr_step, curr_turn, curr_theta,move_type] = ...
    goToFlake(agent_pos, agent_theta, curr_flake, Steps, all_bounderies,varargin)
%description: draws a legal move (ending inside the bounderies of the arena
%towards the closest flake


%Input: agent_pos - x,y of agent (1x2)
%       agent_theta - absolute angle in space
%       curr_flake - x,y of flake
%       Steps - vector of the distribution of step sizes
%       boundery - arena boundery (Nx2)


%Output: x_new,y_new - new agents position after legal move
%        curr_step - size of the step that was chosen
%        curr_turn - turn from previous direciton
%        curr_theta - new absolute angle in space
%        move_type - 1 - go to flake


%...........Local Variable definitions..........

% set defaults
default_countTH = 500; % number of attempts to draw a move towards a flake

 
% parse
vars = inputParser;
addParameter(vars,'countTH',default_countTH);

 
parse(vars,varargin{:})
% make variables
COUNT_TH = vars.Results.countTH;

% agent previous pos
x_prev = agent_pos(1);
y_prev = agent_pos(2);


% bounderies
boundery = all_bounderies{1};

% interpulated bounderies
int_boundery_x = all_bounderies{2}(:,1);
int_boundery_y = all_bounderies{2}(:,2);

%.................Main Function.................
flag = 0; % 0 if legal move was not drawn, 1 if it did
COUNT = 0; % count number of attempts to draw a legal move (so we won't get stuch in an endless loop)
while ~flag
    
    % if count_th moves were drawn unsuccessfully for count_th times  - 
    % make step smaller than distance to closes wall
    if COUNT > COUNT_TH 
        % choose move the be the shortest path to wall to keep agent inside
        DD = calculateNorm([int_boundery_x - x_prev int_boundery_y-y_prev]);
        curr_step = min(DD)*0.99;
    else
        curr_step = emprand(Steps); %draw a step length (maybe big step;
    end

    % define direction from agent to flake
    curr_dir = curr_flake - agent_pos;
    
    % take a step in the direction of the flake at the length
    % decided
    curr_move = curr_dir/calculateNorm(curr_dir).*curr_step;
    
    %currnet turn and current angle
    [~, curr_turn] = angOfVectors([cosd(agent_theta) sind(agent_theta)],curr_move,1);
    curr_turn(curr_turn>180) = curr_turn(curr_turn>180) - 360;
    [~, curr_theta] = angOfVectors([1 0],curr_move,1);
    
    %move in the direction of the flake
    x_new = x_prev + curr_move(1); y_new = y_prev + curr_move(2);
    % check if move is 'legal' (stays inside the arena)
    flag = inpolygon(x_new,y_new,boundery(:,1),boundery(:,2));
    
    COUNT = COUNT+1; % count the attepmted moves
    move_type = 1; % move towards a flake
    
end





%............Call for local functions...........




